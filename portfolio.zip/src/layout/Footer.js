import React from 'react';

function Footer() {
    return (
        <footer>
            <hr />
            Footer  IS HERE
        </footer>
    );
}

export default Footer;