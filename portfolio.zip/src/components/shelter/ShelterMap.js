import MapContainer from 'map/MapContainer';
import React from 'react';
import ShelterList from './ShelterList';


/** 
목록 출력 db데이터 꺼내오려면 ? 머가 필요하노 ㅇㅅㅇ
*/

export default function ShelterMap(props) {
    return (
        <div>
            <MapContainer/>
        </div>
    )
}