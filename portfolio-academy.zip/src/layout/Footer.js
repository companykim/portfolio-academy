import React from 'react';

function Footer() {
    return (
        <footer>
            <hr />
            <b>Created By Team 대피소 안내해드려요 in Korea Vocational Training Institute</b>
            <br/>
        </footer>
    );
}

export default Footer;